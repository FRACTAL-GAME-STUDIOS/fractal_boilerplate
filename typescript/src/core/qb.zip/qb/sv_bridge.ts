import { Item, Server } from '@zerio2/qbcore.js'
let QBCore: Server = exports['qb-core'].GetCoreObject()

export const Init = async () => {
    await Promise.all([InitBridge()]);
}

function InitBridge(): any {
	console.log('Se ha detectado como Framework activo: QB, cargando funciones de QB.')
    let Framework: string = 'qb';

    function GetPlayer(source: number) {
        return QBCore.Functions.GetPlayer(source);
    }

    function KickPlayer(source: number, reason: string, setKickReason: (reason: string) => void, deferrals: unknown) {
        return QBCore.Functions.Kick(source, reason, setKickReason, deferrals);
    }

    function HasGroup(source: string, filter: string | Record<string, number> | string[]): [string, number] | undefined {
        const groups: string[] = ['job', 'gang'];
        const player = GetPlayer(source);
        const typeOfFilter = typeof filter;

        if (typeOfFilter === 'string') {
            for (const group of groups) {
                const data = player.PlayerData[group];
                if (data.name === filter) {
                    return [data.name, data.grade.level];
                }
            }
        } else {
            const tableType = Array.isArray(filter) ? 'array' : 'hash';

            if (tableType === 'hash') {
                for (const group of groups) {
                    const data = player.PlayerData[group];
                    const grade = filter[data.name];
                    if (grade !== undefined && grade <= data.grade.level) {
                        return [data.name, data.grade.level];
                    }
                }
            } else if (tableType === 'array') {
                for (const group of filter as string[]) {
                    for (const groupType of groups) {
                        const data = player.PlayerData[groupType];
                        if (data.name === group) {
                            return [data.name, data.grade.level];
                        }
                    }
                }
            }
        }
        return undefined;
    }

    function GetIdentifier(source: number) {
        let player = QBCore.Functions.GetPlayer(source);
        return player.PlayerData.citizenid;
    }

    function GetName(source: number) {
        let player = QBCore.Functions.GetPlayer(source);
        return player.PlayerData.charinfo.firstname + ' ' + player.PlayerData.charinfo.lastname;
    }

    function RegisterUsableItem(item: string, cb: (source: number, item: Item) => void) {
        QBCore.Functions.CreateUseableItem(item, cb);
    }

    function HasItem(source: number, search: string) {
        let player = GetPlayer(source);
        let item = player.Functions.GetItemByName(search);
		return item?.amount || 0;
    }

    function AddItem(source: number, item: string, count: number, slot: any, metadata: any) {
        let player = GetPlayer(source);
        return player.Functions.AddItem(item, count, slot, metadata);
    }

    function RemoveItem(source: number, item: string, count: number, slot: any) {
        let player = GetPlayer(source);
        return player.Functions.RemoveItem(item, count, slot);
    }

    function AddMoney(source: number, type: string, amount: number) {
        if (type == 'money') type = 'cash';
        let player = GetPlayer(source);
        return player.Functions.AddMoney(type, amount);
    }

    function RemoveMoney(source: number, type: string, amount: number) {
        if (type == 'money') type = 'cash';
        let player = GetPlayer(source);
        return player.Functions.RemoveMoney(type, amount);
    }

    function GetMoney(source: number, type: string) {
        if (type == 'money') type = 'cash';
        let player = GetPlayer(source);
        return player.PlayerData[type];
    }

	function RegisterServerCallback(name: string, cb) {
		QBCore.Functions.CreateCallback(name, cb);
	}
}