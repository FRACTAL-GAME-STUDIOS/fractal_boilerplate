export interface PlayerData {
    citizenid: string;
    steam: string;
    license: string;
    name: string;
    job: JobData;
    gang: GangData;
    inventory: InventoryItem[];
    metadata: Metadata;
    money: MoneyData;
    position: Position;
}

interface JobData {
    name: string;
    label: string;
    payment: number;
    grade: {
        name: string;
        label: string;
        payment: number;
    };
}

interface GangData {
    name: string;
    label: string;
}

interface InventoryItem {
    name: string;
    amount: number;
    info: any;
    label: string;
    weight: number;
    type: string;
    description: string;
    unique: boolean;
    useable: boolean;
    image: string;
}

interface Metadata {
    hunger: number;
    thirst: number;
    stress: number;
}

interface MoneyData {
    cash: number;
    bank: number;
}

interface Position {
    x: number;
    y: number;
    z: number;
    a: number;
}

type GroupType = 'job' | 'gang';

interface Grade {
  level: number;
}

interface GroupData {
  name: string;
  grade: Grade;
}