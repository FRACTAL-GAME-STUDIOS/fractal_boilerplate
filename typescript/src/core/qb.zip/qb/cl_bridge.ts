import { Client } from '@zerio2/qbcore.js';
import { PlayerData } from "./interfaces/QB.interface";

// @ts-ignore
let QBCore: Client = exports['qb-core'].GetCoreObject();

export const Init = async () => {
    await Promise.all([InitBridge()]);
}

function InitBridge(): any {
	console.log('Se ha detectado como Framework activo: QB, cargando funciones de QB.')
    let Framework: string = 'qb';
    let PlayerLoaded: boolean = false;
    let PlayerData: PlayerData | undefined = {
        citizenid: "",
        steam: "",
        license: "",
        name: "",
        job: undefined,
        gang: undefined,
        inventory: [],
        metadata: undefined,
        money: undefined,
        position: undefined
    };

    AddStateBagChangeHandler('inLoggedIn', '', (_bagName: string, _key: string, value: any, _reserved: number, _replicated: boolean) => {
        if (value) {
            PlayerData = QBCore.Functions.GetPlayerData() || undefined;
        } else {
            PlayerData = {
                citizenid: "",
                steam: "",
                license: "",
                name: "",
                job: undefined,
                gang: undefined,
                inventory: [],
                metadata: undefined,
                money: undefined,
                position: undefined
            };
        }
        PlayerLoaded = value;
    });

    on('onResourceStart', (resourceName: string) => {
        if (GetCurrentResourceName() != resourceName) return;
        PlayerData = QBCore.Functions.GetPlayerData();
        PlayerLoaded = true;
    });

    on('gameEventTriggered', (event: string, data: any) => {
        if (event != 'CEventNetworkEntityDamage') return;
        let victim: number = data[1];
        let victimDied: boolean = data[4];

        if (!IsPedAPlayer(victim)) return;
        let player = PlayerId();
        if (victimDied && NetworkGetPlayerIndexFromPed(victim) == player && (IsPedDeadOrDying(victim, true) || IsPedFatallyInjured(victim))) {
            // MY EVENT WHEN DIE
        }
    });

    onNet('QBCore:Client:OnPlayerLoaded', () => {
        // My events when player spawn
    });

    onNet('QBCore:Client:OnPlayerUnload', () => {
        // My events when player unload
    });

    onNet('QBCore:PLayer:SetPlayerData', (newPlayerData: PlayerData, source: string) => {
        if (source !== '' && GetInvokingResource() !== '') return;
        PlayerData = newPlayerData;
    });

    function HasGroup(filter: string | Record<string, number> | string[]): [string, number] | undefined {
        const groups: string[] = ['job', 'gang'];
        const typeOfFilter = typeof filter;

        if (typeOfFilter === 'string') {
            for (const group of groups) {
                const data = PlayerData[group];
                if (data.name === filter) {
                    // @ts-ignore
                    return [data.name, data.grade.level];
                }
            }
        } else {
            const tableType = Array.isArray(filter) ? 'array' : 'hash';

            if (tableType === 'hash') {
                for (const group of groups) {
                    const data = PlayerData[group];
                    const grade = filter[data.name];
                    // @ts-ignore
                    if (grade !== undefined && grade <= data.grade.level) {
                        // @ts-ignore
                        return [data.name, data.grade.level];
                    }
                }
            } else if (tableType === 'array') {
                for (const group of filter as string[]) {
                    for (const groupType of groups) {
                        const data = PlayerData[groupType];
                        if (data.name === group) {
                            // @ts-ignore
                            return [data.name, data.grade.level];
                        }
                    }
                }
            }
        }
        return undefined;
    }
}
